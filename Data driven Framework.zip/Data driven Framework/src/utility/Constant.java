package utility;

public class Constant {
	
	public static final String URL = "https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin";
	 
    public static final String Username = "narenderreddy426@gmail.com";

    public static final String Password = "darling@123";

    public static final String Path_TestData = "C://Data.xlsx";

    public static final String File_TestData = "TestData.xlsx";

}
