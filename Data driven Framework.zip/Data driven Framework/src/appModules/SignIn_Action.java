	package appModules;

import org.openqa.selenium.WebDriver;

import pageObjects.Home_Page;
import pageObjects.LogIn_Page;
import utility.ExcelUtils;

public class SignIn_Action {
	
	public static void Execute(WebDriver driver) throws Exception{
		 
		//This is to get the values from Excel sheet, passing parameters (Row num ; Col num)to getCellData method
		 
		String sUserName = ExcelUtils.getCellData(1, 0);
		 
		String sPassword = ExcelUtils.getCellData(1, 1);
		 
		Home_Page.lnk_MyAccount(driver).click();
		 
		LogIn_Page.txtbx_UserName(driver).sendKeys("magentoqa");
		 
		LogIn_Page.txtbx_Password(driver).sendKeys("Dotcom@123");
		 
		LogIn_Page.btn_LogIn(driver).click();
		 
		        }

}
