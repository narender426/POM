package globals;

public class Constants {

	public static String fbb_URL = "";
	public static String fbb_UserName = "smriti.jha@embitel.com";
	public static String fbb_Password = "Fashion@123";
	public static String Pincode="";
	
	public static String live_FutureGroup_URL = "";
	public static String live_FutureGroup_UserName = "";
	public static String live_FutureGroup_Password = "";
	
	
	public static String excelFilePath = "/data/EMBITEL/emb-vishsha/workspace/FutureGroup/src/DataUtilities/LoginData.xlsx";
	public static String excelFileName = "";
	public static String excelSheetName = "";
	public static String cardnumber = "5123456789012346";
	public static String cardname = "Test";
	public static String cardexpiryyear = "2017";
	public static String cvvnumber = "123";
	
	public static String fbb_RegdId = "smritijha22@gmail.com";
	public static String fbb_RegdFirstName = "Smriti";
	public static String fbb_RegdLastName = "Jha";
	public static String fbb_RegdPwd = "123123";
	public static String fbb_RegdCfmPwd = "123123";
	public static String fbb_RegdCntnber = "9886589291";
	
	public static String fbb_Facebook_Username = "smritijha406@gmail.com";
	public static String fbb_Facebook_Passwod = "gabrielokara";
	
	public static String fbb_Google_Username = "smritijha22@gmail.com";
	public static String fbb_Google_Passwod = "gabrielokara";

	//Objects xpath
	public static String AddtoBagSize_PLP = ".//*[@id='productsCatalog']/li[2]/div/div[2]/div[4]/div/div/div/div[3]/div/span[2]";
	public static String ViewBagButton = ".//*[@class='btn-view-cart']";
	public static String CreditCard_Tab = ".//*[@id='payment-form']/div[1]/div/ul/li[1]/a";
	public static String OrderNo = ".//*[@id='content']/div[2]/div[2]/div[1]/div[2]/p/span[1]";
	public static String clickWomens = ".//*[@id='main-menu']/ul/li[2]/div[1]/a/span";
	public static String CardName = ".//*[@id='cc_holder']";
	public static String saveforLaterPopUp = ".//*[@id='page']/header/div/div/div/div[3]/div[4]";
	public static String addToBagSize = ".//*[@id='productsCatalog']/li/div/div/div[3]/div/div[3]/span[2]";
	public static String addToBagPopupMsg = ".//*[@id='page']/header/div/div/div/div[3]/div[4]/div[2]/p";
	public static String deleteProductMsg = ".//*[@id='page']/header/div/div/div/div[3]/div[4]";
	public static String PLPimage = ".//*[@id='productsCatalog']/li[2]/div/div[2]/a";
	public static String ProceedtoPayment_Button = ".//*[@id='checkoutBtn']";
	
	public static String QuickViewproduct_size = "//div[@class='size-left']/span[@data-js-variant='DJ006WJ27ACUINFUR-259' and  @class='sizebox2 sizeboxtext']";
	
	
}
